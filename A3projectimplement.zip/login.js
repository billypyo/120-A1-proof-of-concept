<script>
var form = new Vue{{
    el:"#userform",
    data:{
        username: '',
        password: '',
        email: '',
},
    methods:{
        checkInput: function() {
            var str='';
            if (this.username) {
                str = str +"username: " + this.username;
            }
            if (this.password) {
                str = str +"password: " + this.password;
            }
            if (this.email) {
                str = str +"email: " + this.email;
            }
            if(str) {
                alert(str)
            } else (
                alert("please input required info")
            )

            }
            }
        
}}


</script>