<script>
var selected = new Vue{{
    el:"#select",
    data:{
    selected: 'A',
    options:[
        {text:'Sweet', vaule:'A'},
        {text:'Sour', vaule:'B'},
        {text:'Bitter', vaule:'C'},
        {text:'Hot', vaule:'D'},
        {text:'Cold', vaule:'E'},
        {text:'Fried', vaule:'F'},
        {text:'Roast', vaule:'G'},
        {text:'Salty', vaule:'H'},
    ]
        
    }
}}



</script>