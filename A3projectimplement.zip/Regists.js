<script>
var resgist = new Vue{{
    el:"#Regists",
    data:{
        username: '',
        password: '',
        cpassword:'',
        email: '',
},
    methods:{
        checkInput: function() {
            var str='';
            if (this.username) {
                str = str +"username: " + this.username;
            }
            if (this.password) {
                str = str +"password: " + this.password;
            }
            if (this.cpassword) {
                str = str +"confirm password: " + this.cpassword;
            }
            if (this.email) {
                str = str +"email: " + this.email;
            }
            if(str) {
                alert(str)
            } else (
                alert("please input required info")
            )

            }
            }
        
}}


</script>